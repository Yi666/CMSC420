package projects.phonebook.hashes;

import projects.phonebook.utils.*;

/**<p>{@link SeparateChainingHashTable} is a {@link HashTable} that implements <b>Separate Chaining</b>
 * as its collision resolution strategy, i.e the collision chains are implemented as actual
 * Linked Lists. These Linked Lists are <b>not assumed ordered</b>. It is the easiest and most &quot; natural &quot; way to
 * implement a hash table and is useful for estimating hash function quality. In practice, it would
 * <b>not</b> be the best way to implement a hash table, because of the wasted space for the heads of the lists.
 * Open Addressing methods, like those implemented in {@link LinearProbingHashTable} and {@link QuadraticProbingHashTable}
 * are more desirable in practice, since they use the original space of the table for the collision chains themselves.</p>
 *
 * @author Yi Liu
 * @see HashTable
 * @see SeparateChainingHashTable
 * @see LinearProbingHashTable
 * @see CollisionResolver
 */
public class SeparateChainingHashTable implements HashTable{


    /* *******************************************************************/
    /* ***** PRIVATE FIELDS / METHODS PROVIDED TO YOU: DO NOT EDIT! ******/
    /* ****************************************************** ***********/
    private static final RuntimeException UNIMPL_METHOD = new RuntimeException("Implement this method!");
    private KVPairList[] table;
    private int count;
    private PrimeGenerator primeGenerator;

    private int hash(String key){
        return (key.hashCode() & 0x7fffffff) % table.length;
    }

    /* ******************/
    /*  PUBLIC METHODS: */
    /* ******************/
    /**
     *  Default constructor. Initializes the internal storage with a size equal to the default of {@link PrimeGenerator}.
     *  This constructor is <b>GIVEN TO YOU; DO NOT EDIT IT!</b>
     */
    public SeparateChainingHashTable(){
        primeGenerator = new PrimeGenerator();
        table = new KVPairList[primeGenerator.getCurrPrime()];
        for(int i = 0; i < table.length; i++){
            table[i] = new KVPairList();
        }
        count = 0;
    }

    @Override
    public void put(String key, String value) {
        int hashCode = hash(key);
        /*if (table[hashCode].containsKey(key)) {
            table[hashCode].updateValue(key,value);
            }
        else if (table[hashCode].containsValue(value)) {
            table[hashCode].updateKey(key, value);
        }
        else{*/
            table[hashCode].addBack(key, value);
            count += 1;

    }

    @Override
    public String get(String key) {
        int hashCode = hash(key);
        if (!table[hashCode].containsKey(key)) {
            return null;
        }
        else {
            return table[hashCode].getValue(key);
        }
    }

    @Override
    public String remove(String key) {
        int hashCode = hash(key);
        if (table[hashCode].containsKey(key)) {
            String value = table[hashCode].getValue(key);
            table[hashCode].removeByKey(key);
            count -= 1;
            return value;
        }
        else{
            return null;
        }
    }

    @Override
    public boolean containsKey(String key) {
        int hashCode = hash(key);
        if (table[hashCode].containsKey(key)){
            return true;
        }
        else{
            return false;
        }
    }

    @Override
    public boolean containsValue(String value) {
        for(int i = 0; i < table.length; i++){
            if (table[i].containsValue(value)){
                return true;
            }
        }
        return false;
    }

    @Override
    public int size() {
        return count;
    }

    @Override
    public int capacity() {
        return table.length;
    }
    /**
     * Enlarges this hash table. At the very minimum, this method should increase the <b>capacity</b> of the hash table and ensure
     * that the new size is prime. The class {@link PrimeGenerator} implements the enlargement heuristic that
     * we have talked about in class and can be used as a black box if you wish.
     * @see PrimeGenerator#getNextPrime()
     */
    public void enlarge() {

        int originalLength = table.length;
        int newLength = primeGenerator.getNextPrime();
        KVPairList[] table1 = table.clone();
        table = new KVPairList[newLength];
        for(int i = 0; i < table.length; i++){
            table[i] = new KVPairList();
        }


        for(int i = 0; i < originalLength; i++){
            if (table1[i] != null) {
                if (table1[i].iterator().hasNext()) {
                    KVPair kvPair = table1[i].iterator().next();

                    int hashCode = hash(kvPair.getKey());
                    table[hashCode].addBack(kvPair.getKey(),kvPair.getValue());
                }
            }


                /*while (table1[i].iterator().hasNext()) {
                    KVPair kvPair = table1[i].iterator().next();

                    int hashCode = hash(kvPair.getKey());

                    System.out.println("key " + kvPair.getKey());
                    System.out.println("code " + hashCode);
                    System.out.println("length " + table.length);

                    table[hashCode].addBack(kvPair.getKey(),kvPair.getValue());
                }
            }*/
        }
    }

    /**
     * Shrinks this hash table. At the very minimum, this method should decrease the size of the hash table and ensure
     * that the new size is prime. The class {@link PrimeGenerator} implements the shrinking heuristic that
     * we have talked about in class and can be used as a black box if you wish.
     *
     * @see PrimeGenerator#getPreviousPrime()
     */
    public void shrink(){
        int originalLength = table.length;
        int newLength = primeGenerator.getPreviousPrime();
        KVPairList[] table1 = table.clone();
        table = new KVPairList[newLength];
        for(int i = 0; i < table.length; i++){
            table[i] = new KVPairList();
        }


        for(int i = 0; i < originalLength; i++){
            if (table1[i] != null) {
                if (table1[i].iterator().hasNext()) {
                    KVPair kvPair = table1[i].iterator().next();
                    int hashCode = hash(kvPair.getKey());
                    table[hashCode].addBack(kvPair.getKey(),kvPair.getValue());
                }
            }
        }


    }

}
